﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit.Abstractions;
using Xunit;

namespace RomanNumeralAddition
{
    
    public class RomanTesting
    {
        Calculator Calculator = new Calculator();
        [Fact]
        public void RomanNumeralCoversionToNumberTest()
        {
            string input = "LV";
            RomanNumeral one = new RomanNumeral(input);
            int output = one.NumberValue;

            Assert.Equal(55, output);
        }

        [Fact]
        public void romanNumeralCoversionToNumeralTest()
        {
            RomanNumeral one = new RomanNumeral();
            one.NumberValue = 155;
            string output = one.Numeral;

            Assert.Equal("CLV", output);
        }

        [Fact]
        public void romanNumeralToNumberTest()
        {
            string numeral = "LV";
            int value = Calculator.createNumberValue(numeral);

            Assert.True(value == 55);
        }

        [Fact]
        public void numberToRomanNumeralTest()
        {
            int value = 155;
            string numeral = Calculator.createNumeralValue(value);

            Assert.True(numeral == "CLV");
        }
    }
}
